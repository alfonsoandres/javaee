package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



//Implemento el modelo con  Patrón Singleton es casi equivalente a crear a conexión
//en el método init de Servlet

public class AccesoDatos {

	private static AccesoDatos modelo;
	private static Connection conexion = null;
	private PreparedStatement stmt_Productos = null;
    private PreparedStatement stmt_Producto  = null;
    private PreparedStatement stmt_borprod  = null;
    private PreparedStatement stmt_modprod  = null;
    private PreparedStatement stmt_creaprod = null;
	
	public static synchronized  AccesoDatos initModelo(){
		if (modelo == null){
			modelo = new AccesoDatos();
		}
		return modelo;
	}
	
	// Creo un lista de alimentos, podría obtenerse de una base de datos
	private AccesoDatos (){
		try {
			
			Class.forName("com.mysql.jdbc.Driver");

			conexion = DriverManager.getConnection(
					"jdbc:mysql://localhost/EMPRESA", "root", "root");

			
			 this.stmt_Productos  = conexion.prepareStatement("select * from prodcutos");
		     this.stmt_Producto   = conexion.prepareStatement("select * from prodcutos where producto_no=?");
		     this.stmt_borprod   = conexion.prepareStatement("delete from Productos where login =?");
		     this.stmt_modprod   = conexion.prepareStatement("update Productos set nombre=?, password=?, comentario=? where login=?");
		     this.stmt_creaprod  = conexion.prepareStatement("insert into Productos (login,nombre,password,comentario) Values(?,?,?,?)");
			

		} catch (Exception ex) {
			System.err.println(" Error - En la base de datos.");
			ex.printStackTrace();
		}
	}
	
	
	 public static void closeModelo(){
	        if (modelo != null){
	           try {
				conexion.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        }
	    }

    // Devuelvo la lista de Productos
    public ArrayList<Producto> getProductos () {
        ArrayList <Producto> tprod = new ArrayList<Producto>();
        
        ResultSet rs; 
        try {
			rs =  this.stmt_Productos.executeQuery();
			  while ( rs.next()) {
		        	Producto usr = new Producto();
		        	usr.setProducto_no("PR);
		        	usr.setDescripcion("descripcion");
		        	usr.setPrecio_actual(null);
                    usr.setStock_disponible(0);
                    tprod.add(usr);
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      
    
        return tprod;
    }
	
    // Obtengo un Producto
    public Producto getProducto(String id) {
    	Producto usr = null;
    	
        ResultSet rs; 
        try {
        	this.stmt_Producto.setString(1, id);
			rs =  this.stmt_Producto.executeQuery();
			  if  ( rs.next()) {
		        	usr = new Producto();
		        	usr.setProducto_no(0);
		        	usr.setDescripcion(null);
		        	usr.setPrecio_actual(null);
                    usr.setStock_disponible(0);
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          	return usr;
    }
	
    // UPDATE
  /*  public boolean modProducto(Producto prod){
      
    	boolean resu = false;
        try {
		
			stmt_modprod.setInt(1,prod.setProducto_no(0));
	        stmt_modprod.setString(2,prod.setDescripcion(null));
	        stmt_modprod.setString(3,prod.setPrecio_actual(null));
	    	stmt_modprod.setString(4,prod.setStock_disponible(0));
	        resu = stmt_modprod.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}       
        return resu;
    }
    
    //INSERT
    public boolean addProducto(Producto prod){
        boolean resu = false;
    	try {
    	stmt_creaprod.setString(1,prod.getLogin());
		stmt_creaprod.setString(2,prod.getNombre());
        stmt_creaprod.setString(3,prod.getPassword());
        stmt_creaprod.setString(4,prod.getComentario());
        resu = stmt_creaprod.execute();
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
        return resu;
    }
    
    
    // DELETE Elimino un Producto
    public boolean borrarProducto(String login)  {
        boolean resu = false;
    	
        try {
        	this.stmt_borprod.setString (1, login);
			resu = this.stmt_borprod.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       return resu; 
        
    }  
    
    
    
	*/
	// Evito que se pueda clonar el objeto.
 @Override
 public AccesoDatos clone(){
         try {
             throw new CloneNotSupportedException();
         } catch (CloneNotSupportedException ex) {
         	ex.printStackTrace();
         }
         return null; 
     }    
}

